﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NPCMove : MonoBehaviour
{
    [SerializeField]
    Transform _destination;

    UnityEngine.AI.NavMeshAgent _navMashAgent;

    // Start is called before the first frame update
    void Start()
    {
        _navMashAgent = this.GetComponent<UnityEngine.AI.NavMeshAgent>();

        if (_navMashAgent == null)
        {
            Debug.LogError("The nav mesh agent is not attached to " + gameObject.name);
        }
        else
        {
            SetDestination();
        }
    }
    private void SetDestination()
    {
        if (_destination != null)
        {
            Vector3 targetVector = _destination.transform.position;
            _navMashAgent.SetDestination(targetVector);

        }
    }
}

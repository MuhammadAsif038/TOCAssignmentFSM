﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngne.AI;


public class EnterState : AdstractFSMState
{
    public override bool EnterState()
    {
        base.EnterState();
        debug.Log("ENTER IDLE STATE");
        return true;
    }
    
    public override void UpdateState()
    {
        base.EnterState();
        debug.Log("UPDATING IDLE STATE");
    }
    
    
    public override bool ExitState()
    {
        base.ExitState();
        debug.Log("EXITING IDLE STATE");
        return true;
    }

}
